//
//  DummyFrameworkFive.h
//  DummyFrameworkFive
//
//  Created by Marc Terns on 9/10/17.
//  Copyright © 2017 Marc Terns. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DummyFrameworkFive.
FOUNDATION_EXPORT double DummyFrameworkFiveVersionNumber;

//! Project version string for DummyFrameworkFive.
FOUNDATION_EXPORT const unsigned char DummyFrameworkFiveVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DummyFrameworkFive/PublicHeader.h>

#import <DummyFrameworkFive/DummyFrameworkFiveProtocols.h>

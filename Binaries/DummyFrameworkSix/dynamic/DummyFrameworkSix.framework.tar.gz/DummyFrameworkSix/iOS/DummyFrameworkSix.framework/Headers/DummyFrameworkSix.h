//
//  DummyFrameworkSix.h
//  DummyFrameworkSix
//
//  Created by Marc Terns on 9/11/17.
//  Copyright © 2017 Marc Terns. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DummyFrameworkSix.
FOUNDATION_EXPORT double DummyFrameworkSixVersionNumber;

//! Project version string for DummyFrameworkSix.
FOUNDATION_EXPORT const unsigned char DummyFrameworkSixVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DummyFrameworkSix/PublicHeader.h>

#import <DummyFrameworkSix/DummyFrameworkSixProtocols.h>

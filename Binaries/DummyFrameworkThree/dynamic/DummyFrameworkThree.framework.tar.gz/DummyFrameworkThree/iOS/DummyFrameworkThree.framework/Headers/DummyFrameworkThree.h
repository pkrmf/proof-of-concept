//
//  DummyFrameworkThree.h
//  DummyFrameworkThree
//
//  Created by Marc Terns on 9/10/17.
//  Copyright © 2017 Marc Terns. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DummyFrameworkThree.
FOUNDATION_EXPORT double DummyFrameworkThreeVersionNumber;

//! Project version string for DummyFrameworkThree.
FOUNDATION_EXPORT const unsigned char DummyFrameworkThreeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DummyFrameworkThree/PublicHeader.h>

#import <DummyFrameworkThree/DummyFrameworkThreeProtocols.h>

//
//  DummyFrameworkTwo.h
//  DummyFrameworkTwo
//
//  Created by Marc Terns on 9/9/17.
//  Copyright © 2017 Marc Terns. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DummyFrameworkTwo.
FOUNDATION_EXPORT double DummyFrameworkTwoVersionNumber;

//! Project version string for DummyFrameworkTwo.
FOUNDATION_EXPORT const unsigned char DummyFrameworkTwoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DummyFrameworkTwo/PublicHeader.h>

#import <DummyFrameworkTwo/DTWOSample.h>

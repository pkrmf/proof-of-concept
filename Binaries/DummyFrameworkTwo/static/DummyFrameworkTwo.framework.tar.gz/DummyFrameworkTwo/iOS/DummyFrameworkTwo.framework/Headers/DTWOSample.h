//
//  DTWOSample.h
//  DummyFrameworkTwo
//
//  Created by Marc Terns on 9/9/17.
//  Copyright © 2017 Marc Terns. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DTWOSample : NSObject

- (void)print;

@end

//
//  DummyFrameworkFour.h
//  DummyFrameworkFour
//
//  Created by Marc Terns on 9/10/17.
//  Copyright © 2017 Marc Terns. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DummyFrameworkFour.
FOUNDATION_EXPORT double DummyFrameworkFourVersionNumber;

//! Project version string for DummyFrameworkFour.
FOUNDATION_EXPORT const unsigned char DummyFrameworkFourVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DummyFrameworkFour/PublicHeader.h>
#import <DummyFrameworkFour/DummyFrameworkFourProtocols.h>
